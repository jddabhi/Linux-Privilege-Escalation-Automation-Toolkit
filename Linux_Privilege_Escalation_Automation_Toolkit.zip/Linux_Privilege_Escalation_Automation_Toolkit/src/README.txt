LINUX PRIVILEGE ESCALATION AUTOMATION TOOLKIT
Run on Ubuntu/Linux: python3 src/linux_privilege_auditor.py
Outputs: reports/audit_report.txt and reports/audit_report.json
Python 3 standard library only; no pip packages required.

Modules: system information; SUID/SGID discovery in common binary paths; selected
world-writable paths; sensitive file permissions; non-interactive sudo review;
system cron and cron path review; selected systemd service path/PATH review;
getcap capability review (if installed); kernel version inventory.

SAFETY: This is read-only, detection-only auditing. It never executes exploits,
changes permissions, modifies system files, or attempts root access. Run as a
normal user initially. Some checks may be incomplete without admin visibility.
Findings are indicators requiring manual validation, not confirmed exploits.
Kernel CVE matching is not guessed from version text because distributions
backport fixes; compare package versions with vendor security advisories.
