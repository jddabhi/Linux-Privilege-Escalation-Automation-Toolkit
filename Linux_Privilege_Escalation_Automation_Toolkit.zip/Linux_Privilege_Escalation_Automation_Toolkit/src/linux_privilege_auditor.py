#!/usr/bin/env python3
"""Read-only Linux privilege configuration auditor. No exploitation or changes."""
import os, pwd, grp, platform, subprocess, json, re, shutil
from pathlib import Path
from datetime import datetime

def cmd(args):
    try:
        return subprocess.run(args,capture_output=True,text=True,timeout=8).stdout.strip()
    except Exception as e: return str(e)

def main():
    findings=[]
    def add(check,severity,detail,fix,evidence=""):
        if len(findings)<500:
            findings.append(dict(check=check,severity=severity,detail=detail,mitigation=fix,evidence=evidence[:1000]))
    try: user=pwd.getpwuid(os.getuid()).pw_name
    except Exception: user=str(os.getuid())
    try: groups=[grp.getgrgid(g).gr_name for g in os.getgroups()]
    except Exception: groups=[]
    info=dict(user=user,uid=os.getuid(),groups=groups,kernel=platform.release(),
              platform=platform.platform(),is_root=os.getuid()==0)
    print("LINUX PRIVILEGE ESCALATION AUDITOR — DETECTION ONLY")
    print("[1/7] System information collected:",info["user"],info["kernel"])
    print("[2/7] SUID/SGID scan...")
    for root in ("/bin","/sbin","/usr/bin","/usr/sbin","/usr/local/bin","/opt"):
        if not os.path.exists(root): continue
        for cur,dirs,files in os.walk(root,followlinks=False):
            dirs[:]=[d for d in dirs if d not in ("proc","sys","dev","run")]
            for name in files:
                path=os.path.join(cur,name)
                try: mode=os.stat(path,follow_symlinks=False).st_mode
                except OSError: continue
                if mode&0o4000:
                    sev="HIGH" if name in {"find","awk","perl","python","vim","bash","env"} else "INFO"
                    add("SUID binary",sev,f"SUID bit present: {path}. This alone does not prove exploitability.",
                        "Verify package ownership and necessity; remove unnecessary SUID via approved change control.",oct(mode&0o7777))
                if mode&0o2000:
                    add("SGID binary","MEDIUM",f"SGID bit present: {path}. Review intended group elevation.",
                        "Verify group access and remove unnecessary SGID bits.",oct(mode&0o7777))
    print("[3/7] World-writable and sensitive file permissions...")
    for root in ("/etc","/usr/local/bin","/usr/local/sbin","/opt","/var/spool/cron","/etc/cron.d"):
        if not os.path.exists(root): continue
        for cur,dirs,files in os.walk(root,followlinks=False):
            for name in dirs+files:
                path=os.path.join(cur,name)
                try: mode=os.lstat(path).st_mode
                except OSError: continue
                if mode&0o002:
                    add("World-writable path","HIGH" if path.startswith(("/etc/","/usr/local/bin/")) else "MEDIUM",
                        f"Any local user may write: {path}. Validate whether this is intended.",
                        "Restrict write permission and use trusted owner/group settings.",oct(mode&0o7777))
            if cur.count(os.sep)-root.count(os.sep)>5: dirs[:]=[]
    for path in ("/etc/passwd","/etc/shadow","/etc/group","/etc/sudoers"):
        try: mode=os.stat(path).st_mode&0o777
        except OSError: continue
        bad=(bool(mode&0o022) if path=="/etc/passwd" else bool(mode&0o027))
        if bad: add("Sensitive file permissions","HIGH",f"{path} has mode {oct(mode)}.",
                    "Restore distribution-appropriate ownership and restrictive permissions.",oct(mode))
    print("[4/7] Sudo configuration...")
    if shutil.which("sudo"):
        out=cmd(["sudo","-n","-l"])
        if "NOPASSWD" in out:
            add("Sudo NOPASSWD rule","HIGH","Current sudo listing contains NOPASSWD.",
                "Remove unnecessary NOPASSWD entries; restrict commands and review with visudo.",out)
        else: add("Sudo configuration","INFO","Non-interactive sudo listing: "+(out or "not available"),
                  "Review sudo -l and grant only necessary commands.",out)
    else: add("Sudo configuration","INFO","sudo utility not found.","Review sudo policy with administrator.")
    print("[5/7] Cron and systemd review...")
    cron=[Path("/etc/crontab"),Path("/etc/cron.d"),Path("/etc/cron.hourly"),Path("/etc/cron.daily"),
          Path("/etc/cron.weekly"),Path("/etc/cron.monthly")]
    for p in cron:
        if not p.exists(): continue
        fs=[p] if p.is_file() else list(p.iterdir())[:200]
        for f in fs:
            try:
                st=f.stat()
                if st.st_mode&0o022:
                    add("Writable cron configuration","HIGH",f"{f} is group/world writable.",
                        "Set trusted ownership and restrict write access.",oct(st.st_mode&0o7777))
                for line in f.read_text(errors="ignore").splitlines():
                    s=line.strip()
                    if s and not s.startswith("#") and any(x in s for x in ("/home/","/tmp/","/var/tmp/")):
                        add("Cron path review","MEDIUM",f"Cron entry references potentially writable path: {s[:180]}",
                            "Use root-owned scripts in protected directories.",s)
            except OSError: pass
    units=Path("/etc/systemd/system")
    if units.exists():
        for f in list(units.glob("*.service"))[:200]:
            try: content=f.read_text(errors="ignore")
            except OSError: continue
            for line in content.splitlines():
                s=line.strip()
                if s.startswith(("ExecStart=","ExecStartPre=","ExecStartPost=")) and any(x in s for x in ("/tmp/","/var/tmp/","/home/")):
                    add("Systemd executable path review","HIGH",f"{f.name}: {s}",
                        "Use root-owned executables and protected directories; review User=, Group= and permissions.",s)
                if s.startswith("Environment=PATH=") and any(x in s for x in (":.","/tmp","/home")):
                    add("Systemd PATH review","MEDIUM",f"{f.name}: {s}",
                        "Set a fixed PATH containing only trusted administrator-controlled directories.",s)
    print("[6/7] Capabilities and kernel information...")
    if shutil.which("getcap"):
        out=cmd(["getcap","-r","/usr/bin","/usr/sbin","/usr/local/bin"])
        for line in out.splitlines():
            if line: add("File capability","MEDIUM","Review capability assignment.", "Remove unnecessary capabilities.",line)
    else: add("Linux capabilities","INFO","getcap unavailable; scan skipped.","Install getcap if capability review is required.")
    add("Kernel version","INFO",f"Detected kernel: {info['kernel']}. No unsupported CVE guess is made.",
        "Compare exact distro package against vendor advisories; apply supported security updates.",cmd(["uname","-a"]))
    add("Kernel CVE validation","INFO","Kernel version alone is insufficient for reliable CVE matching due to distro backports.",
        "Check Ubuntu/Debian/Red Hat vendor security advisories and package changelogs.")
    counts={s:sum(1 for f in findings if f["severity"]==s) for s in ("HIGH","MEDIUM","LOW","INFO")}
    report=dict(tool="Linux Privilege Escalation Automation Toolkit",generated=datetime.now().isoformat(timespec="seconds"),
                scope="Read-only local detection; manually validate all findings.",system=info,summary=counts,findings=findings)
    Path("reports").mkdir(exist_ok=True)
    Path("reports/audit_report.json").write_text(json.dumps(report,indent=2))
    with open("reports/audit_report.txt","w") as f:
        f.write(report["tool"]+"\\n"+json.dumps(info,indent=2)+"\\nSUMMARY "+json.dumps(counts)+"\\n\\n")
        for i,x in enumerate(findings,1):
            f.write(f"{i}. [{x['severity']}] {x['check']}\\n{x['detail']}\\nMitigation: {x['mitigation']}\\nEvidence: {x['evidence']}\\n\\n")
    print("[7/7] Complete. Findings:",len(findings),"Severity:",counts)
    print("Reports: reports/audit_report.txt and reports/audit_report.json")
    print("Detection only: no exploitation, permission changes, or root access attempts.")
if __name__=="__main__": main()
